# reveal.js-demos

This repository contains demos for the reveal.js plugins provided [here](https://github.com/rajgoel/reveal.js-plugins/) and a [presenter for markdown files](https://rajgoel.github.io/reveal.js-demos/markdown-presenter.html) such as [this one](https://rajgoel.github.io/reveal.js-demos/example.md). Please note that all demos require [reveal.js](https://github.com/hakimel/reveal.js) and [reveal.js-plugins](https://github.com/rajgoel/reveal.js-plugins).
